from django.apps import AppConfig


class DeliverystaffConfig(AppConfig):
    name = 'deliverystaff'
