from django.apps import AppConfig


class EadminConfig(AppConfig):
    name = 'eadmin'
